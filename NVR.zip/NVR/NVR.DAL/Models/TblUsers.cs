﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace NVR.DAL.Models
{
    public partial class TblUsers
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailId { get; set; }
        public string PhoneNumber { get; set; }
        public int DesignationId { get; set; }
        public int LocationId { get; set; }
        public int RoleId { get; set; }

        public virtual TblDesignations Designation { get; set; }
        public virtual TblLocations Location { get; set; }
        public virtual TblRoles Role { get; set; }
    }
}
