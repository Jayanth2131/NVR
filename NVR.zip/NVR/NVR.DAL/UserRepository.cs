﻿using NVR.DAL.Interfaces;
using NVR.DAL.Models;
using NVR.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NVR.DAL
{
    public class UserRepository :IUserRepository
    {
        private readonly NVRContext _context;
        public UserRepository(NVRContext context)
        {
            _context = context;
        }

        public List<CountryDTO> GetCountriesList()
        {
           var countriesList = _context.TblLocations.Select(c => new CountryDTO() { CountryId = c.LocationId, Name = c.Name }).ToList();
            return countriesList;
        }

        public List<DesignationDTO> GetDesingationsList()
        {
            return _context.TblDesignations.Select(c => new DesignationDTO() { Id = c.DesignationId, Name = c.Name }).ToList();
        }

        public List<RoleDTO> GetRolesList()
        {
            return _context.TblRoles.Select(c => new RoleDTO() { RoleId = c.RoleId, RoleName = c.RoleName }).ToList();
        }

        public bool createuser(UserDTO userIinput)
        {
            bool status = false;

            TblUsers dbInput = new TblUsers();
            dbInput.FirstName = userIinput.FirstName;
            dbInput.LastName = userIinput.LastName;
            dbInput.PhoneNumber = userIinput.PhoneNo.ToString();
            dbInput.EmailId = userIinput.EmailId;
            dbInput.DesignationId = userIinput.DesignationId;
            dbInput.LocationId = userIinput.CountryId;
            dbInput.RoleId = userIinput.RoleId;

            _context.TblUsers.Add(dbInput);
            status = _context.SaveChanges() > 0 ? true : false;

            return status;
        }
    }
}
