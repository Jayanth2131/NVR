﻿using NVR.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace NVR.DAL.Interfaces
{
    public interface IUserRepository
    {
        public List<CountryDTO> GetCountriesList();
        public List<DesignationDTO> GetDesingationsList();
        public List<RoleDTO> GetRolesList();
        public bool createuser(UserDTO userIinput);
    }
}
