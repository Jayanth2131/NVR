﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using NVR.BL.Interfaces;
using NVR.DTO;
using System.Collections.Generic;

namespace NVR.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }
        // GET: UserController
        public ActionResult Index()
        {
            List<UserDTO> userList = new List<UserDTO>();
            return View(userList);
        }

        // GET: UserController/Details/5
        public ActionResult Details(int id)
        {
            return View(new UserDTO());
        }

        // GET: UserController/Create
        public ActionResult Create()
        {
            List<SelectListItem> countryList = new List<SelectListItem>();
            var dbList = _userService.GetCountriesList();
            foreach(var item in dbList)
            {
                countryList.Add(new SelectListItem { Text = item.Name, Value = item.CountryId.ToString() });
            }

            List<SelectListItem> designationList = new List<SelectListItem>();
            var dbdesignationList = _userService.GetDesingationsList();
            foreach (var item in dbdesignationList)
            {
                designationList.Add(new SelectListItem { Text = item.Name, Value = item.Id.ToString() });
            }

            var dbrolesList = _userService.GetRolesList();
            List<SelectListItem> rolesList = new List<SelectListItem>();
            foreach (var item in dbrolesList)
            {
                rolesList.Add(new SelectListItem { Text = item.RoleName, Value = item.RoleId.ToString() });
            }

            ViewData["RolesList"] = rolesList;
            ViewBag.CountryList = countryList;
            ViewBag.DesignationList = designationList;
            return View(new UserDTO());
        }

        public ActionResult GetRoles()
        {
            var rolesList = _userService.GetRolesList();
            
            return View(rolesList);
        }

        // POST: UserController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(UserDTO userINput, IFormCollection collection)
        {
            try
            {
                if (ModelState.IsValid)
                {

                }
                return View(userINput);
            }
            catch
            {
                return View();
            }
        }

        // GET: UserController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: UserController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: UserController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: UserController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
