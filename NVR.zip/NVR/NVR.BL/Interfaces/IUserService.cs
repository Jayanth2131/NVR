﻿using NVR.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace NVR.BL.Interfaces
{
    public interface IUserService
    {
        public List<CountryDTO> GetCountriesList();
        public List<DesignationDTO> GetDesingationsList();
        public List<RoleDTO> GetRolesList();
        public bool createuser(UserDTO userIinput);
    }
}
