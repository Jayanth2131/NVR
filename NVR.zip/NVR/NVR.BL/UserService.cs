﻿using NVR.BL.Interfaces;
using NVR.DAL.Interfaces;
using NVR.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace NVR.BL
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }
        public List<CountryDTO> GetCountriesList()
        {
            return _userRepository.GetCountriesList();
        }

        public List<DesignationDTO> GetDesingationsList()
        {
            return _userRepository.GetDesingationsList();
        }

        public List<RoleDTO> GetRolesList()
        {
            return _userRepository.GetRolesList();
        }

        public bool createuser(UserDTO userIinput)
        {
            return _userRepository.createuser(userIinput);
        }
    }
}
