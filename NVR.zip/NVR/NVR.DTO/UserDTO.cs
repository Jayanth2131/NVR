﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace NVR.DTO
{
    public class UserDTO
    {
       
        public int UserId { get; set; }

        [Display(Name = "First Name")]
        [Required(ErrorMessage ="Please enter FirstName")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name", Description ="capture the user last name")]
        [Required]
        public string LastName { get; set; }

        [DisplayName("Email Id")]
        [Required]
        public string EmailId { get; set; }
        [DisplayName("Phone Number")]
        public long PhoneNo { get; set; }

        [DisplayName("Country")]
        [Required]
        public int CountryId { get; set; }

        [DisplayName("Designation")]
        [Required]
        public int DesignationId { get; set; }

        [DisplayName("Role")]
        [Required]
        public int RoleId { get; set; }
    }
}
