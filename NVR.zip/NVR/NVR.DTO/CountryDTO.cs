﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NVR.DTO
{
    public class CountryDTO
    {
        public int CountryId { get; set; }
        public string Name { get; set; }
    }
}
