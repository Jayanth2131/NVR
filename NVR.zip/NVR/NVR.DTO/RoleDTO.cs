﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NVR.DTO
{
    public class RoleDTO
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
